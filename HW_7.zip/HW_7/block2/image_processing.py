from PIL import Image, ImageEnhance, ImageFilter

class ImageProcessor:
    def __init__(self, image_path):
        """Ініціалізація класу та завантаження зображення."""
        self.image = Image.open(image_path)

    def enhance_contrast(self, factor=2.0):
        """Підвищення контрасту зображення."""
        enhancer = ImageEnhance.Contrast(self.image)
        self.image = enhancer.enhance(factor)

    def find_edges(self):
        """Знаходження контурів на зображенні."""
        # Перетворення на чорно-біле зображення
        self.image = self.image.convert("L")
        # Застосування фільтра для знаходження контурів
        self.image = self.image.filter(ImageFilter.FIND_EDGES)

    def save_image(self, output_path):
        """Збереження обробленого зображення."""
        self.image.save(output_path)
