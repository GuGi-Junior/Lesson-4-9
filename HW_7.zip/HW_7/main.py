import os
from block2.image_processing import ImageProcessor

def main():
    # Шлях до вхідного зображення
    input_image_path = "images/satellite_image.jpg"
    output_image_path = "images/processed_image.jpg"

    # Перевіряємо, чи файл існує
    if not os.path.exists(input_image_path):
        print(f"Файл {input_image_path} не знайдено. Переконайтеся, що шлях вказано правильно.")
        return

    # Ініціалізація обробника зображень
    processor = ImageProcessor(input_image_path)
    processor.enhance_contrast(1.5)
    processor.find_edges()
    processor.save_image(output_image_path)
    print("Зображення успішно оброблено та збережено у", output_image_path)

if __name__ == "__main__":
    main()
